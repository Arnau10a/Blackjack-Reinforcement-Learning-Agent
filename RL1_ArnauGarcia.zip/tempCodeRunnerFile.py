# def plot_series(arr):
#     plt.plot(arr)
#     plt.savefig('moving_average.pdf')